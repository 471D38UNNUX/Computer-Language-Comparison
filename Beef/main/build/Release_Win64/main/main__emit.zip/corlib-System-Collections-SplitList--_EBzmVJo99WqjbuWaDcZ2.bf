int_cosize[0] mOffsets;

int_cosize[0] newOffsets;
int newSizeBytes = 0;
