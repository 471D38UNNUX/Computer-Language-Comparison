#pragma warning disable
public static function comptype(303)(comptype(79) name, comptype(575) createKind, comptype(574) createFlags, comptype(565) createdFileAttrs, comptype(1117) outResult) sBfpFile_Create;
public static comptype(303) BfpFile_Create(comptype(79) name, comptype(575) createKind, comptype(574) createFlags, comptype(565) createdFileAttrs, comptype(1117) outResult)
{
	if (sBfpFile_Create != null)
		return sBfpFile_Create(name, createKind, createFlags, createdFileAttrs, outResult);
	return comptype(295).BfpFile_Create(name, createKind, createFlags, createdFileAttrs, outResult);
}

public static function comptype(303)(comptype(639) kind, comptype(1117) outResult) sBfpFile_GetStd;
public static comptype(303) BfpFile_GetStd(comptype(639) kind, comptype(1117) outResult)
{
	if (sBfpFile_GetStd != null)
		return sBfpFile_GetStd(kind, outResult);
	return comptype(295).BfpFile_GetStd(kind, outResult);
}

public static function comptype(1)(comptype(303) file) sBfpFile_GetSystemHandle;
public static comptype(1) BfpFile_GetSystemHandle(comptype(303) file)
{
	if (sBfpFile_GetSystemHandle != null)
		return sBfpFile_GetSystemHandle(file);
	return comptype(295).BfpFile_GetSystemHandle(file);
}

public static function comptype(12)(comptype(303) file) sBfpFile_Release;
public static comptype(12) BfpFile_Release(comptype(303) file)
{
	if (sBfpFile_Release != null)
		return sBfpFile_Release(file);
	return comptype(295).BfpFile_Release(file);
}

public static function comptype(1)(comptype(303) file, comptype(55) buffer, comptype(1) size, comptype(1) timeoutMS, comptype(1117) outResult) sBfpFile_Write;
public static comptype(1) BfpFile_Write(comptype(303) file, comptype(55) buffer, comptype(1) size, comptype(1) timeoutMS, comptype(1117) outResult)
{
	if (sBfpFile_Write != null)
		return sBfpFile_Write(file, buffer, size, timeoutMS, outResult);
	return comptype(295).BfpFile_Write(file, buffer, size, timeoutMS, outResult);
}

public static function comptype(1)(comptype(303) file, comptype(55) buffer, comptype(1) size, comptype(1) timeoutMS, comptype(1117) outResult) sBfpFile_Read;
public static comptype(1) BfpFile_Read(comptype(303) file, comptype(55) buffer, comptype(1) size, comptype(1) timeoutMS, comptype(1117) outResult)
{
	if (sBfpFile_Read != null)
		return sBfpFile_Read(file, buffer, size, timeoutMS, outResult);
	return comptype(295).BfpFile_Read(file, buffer, size, timeoutMS, outResult);
}

public static function comptype(12)(comptype(303) file) sBfpFile_Flush;
public static comptype(12) BfpFile_Flush(comptype(303) file)
{
	if (sBfpFile_Flush != null)
		return sBfpFile_Flush(file);
	return comptype(295).BfpFile_Flush(file);
}

public static function comptype(19)(comptype(303) file) sBfpFile_GetFileSize;
public static comptype(19) BfpFile_GetFileSize(comptype(303) file)
{
	if (sBfpFile_GetFileSize != null)
		return sBfpFile_GetFileSize(file);
	return comptype(295).BfpFile_GetFileSize(file);
}

public static function comptype(19)(comptype(303) file, comptype(19) offset, comptype(660) seekKind) sBfpFile_Seek;
public static comptype(19) BfpFile_Seek(comptype(303) file, comptype(19) offset, comptype(660) seekKind)
{
	if (sBfpFile_Seek != null)
		return sBfpFile_Seek(file, offset, seekKind);
	return comptype(295).BfpFile_Seek(file, offset, seekKind);
}

public static function comptype(12)(comptype(303) file, comptype(1117) outResult) sBfpFile_Truncate;
public static comptype(12) BfpFile_Truncate(comptype(303) file, comptype(1117) outResult)
{
	if (sBfpFile_Truncate != null)
		return sBfpFile_Truncate(file, outResult);
	return comptype(295).BfpFile_Truncate(file, outResult);
}

public static function comptype(576)(comptype(79) path) sBfpFile_GetTime_LastWrite;
public static comptype(576) BfpFile_GetTime_LastWrite(comptype(79) path)
{
	if (sBfpFile_GetTime_LastWrite != null)
		return sBfpFile_GetTime_LastWrite(path);
	return comptype(295).BfpFile_GetTime_LastWrite(path);
}

public static function comptype(565)(comptype(79) path, comptype(1117) outResult) sBfpFile_GetAttributes;
public static comptype(565) BfpFile_GetAttributes(comptype(79) path, comptype(1117) outResult)
{
	if (sBfpFile_GetAttributes != null)
		return sBfpFile_GetAttributes(path, outResult);
	return comptype(295).BfpFile_GetAttributes(path, outResult);
}

public static function comptype(12)(comptype(79) path, comptype(565) attribs, comptype(1117) outResult) sBfpFile_SetAttributes;
public static comptype(12) BfpFile_SetAttributes(comptype(79) path, comptype(565) attribs, comptype(1117) outResult)
{
	if (sBfpFile_SetAttributes != null)
		return sBfpFile_SetAttributes(path, attribs, outResult);
	return comptype(295).BfpFile_SetAttributes(path, attribs, outResult);
}

public static function comptype(12)(comptype(79) oldPath, comptype(79) newPath, comptype(705) copyKind, comptype(1117) outResult) sBfpFile_Copy;
public static comptype(12) BfpFile_Copy(comptype(79) oldPath, comptype(79) newPath, comptype(705) copyKind, comptype(1117) outResult)
{
	if (sBfpFile_Copy != null)
		return sBfpFile_Copy(oldPath, newPath, copyKind, outResult);
	return comptype(295).BfpFile_Copy(oldPath, newPath, copyKind, outResult);
}

public static function comptype(12)(comptype(79) oldPath, comptype(79) newPath, comptype(1117) outResult) sBfpFile_Rename;
public static comptype(12) BfpFile_Rename(comptype(79) oldPath, comptype(79) newPath, comptype(1117) outResult)
{
	if (sBfpFile_Rename != null)
		return sBfpFile_Rename(oldPath, newPath, outResult);
	return comptype(295).BfpFile_Rename(oldPath, newPath, outResult);
}

public static function comptype(12)(comptype(79) path, comptype(1117) outResult) sBfpFile_Delete;
public static comptype(12) BfpFile_Delete(comptype(79) path, comptype(1117) outResult)
{
	if (sBfpFile_Delete != null)
		return sBfpFile_Delete(path, outResult);
	return comptype(295).BfpFile_Delete(path, outResult);
}

public static function comptype(13)(comptype(79) path) sBfpFile_Exists;
public static comptype(13) BfpFile_Exists(comptype(79) path)
{
	if (sBfpFile_Exists != null)
		return sBfpFile_Exists(path);
	return comptype(295).BfpFile_Exists(path);
}

public static function comptype(12)(comptype(79) outPath, comptype(323) inOutPathSize, comptype(1117) outResult) sBfpFile_GetTempPath;
public static comptype(12) BfpFile_GetTempPath(comptype(79) outPath, comptype(323) inOutPathSize, comptype(1117) outResult)
{
	if (sBfpFile_GetTempPath != null)
		return sBfpFile_GetTempPath(outPath, inOutPathSize, outResult);
	return comptype(295).BfpFile_GetTempPath(outPath, inOutPathSize, outResult);
}

public static function comptype(12)(comptype(79) outName, comptype(323) inOutNameSize, comptype(1117) outResult) sBfpFile_GetTempFileName;
public static comptype(12) BfpFile_GetTempFileName(comptype(79) outName, comptype(323) inOutNameSize, comptype(1117) outResult)
{
	if (sBfpFile_GetTempFileName != null)
		return sBfpFile_GetTempFileName(outName, inOutNameSize, outResult);
	return comptype(295).BfpFile_GetTempFileName(outName, inOutNameSize, outResult);
}

public static function comptype(12)(comptype(79) inPath, comptype(79) outPath, comptype(323) inOutPathSize, comptype(1117) outResult) sBfpFile_GetFullPath;
public static comptype(12) BfpFile_GetFullPath(comptype(79) inPath, comptype(79) outPath, comptype(323) inOutPathSize, comptype(1117) outResult)
{
	if (sBfpFile_GetFullPath != null)
		return sBfpFile_GetFullPath(inPath, outPath, inOutPathSize, outResult);
	return comptype(295).BfpFile_GetFullPath(inPath, outPath, inOutPathSize, outResult);
}

public static function comptype(12)(comptype(79) inPath, comptype(79) outPath, comptype(323) inOutPathSize, comptype(1117) outResult) sBfpFile_GetActualPath;
public static comptype(12) BfpFile_GetActualPath(comptype(79) inPath, comptype(79) outPath, comptype(323) inOutPathSize, comptype(1117) outResult)
{
	if (sBfpFile_GetActualPath != null)
		return sBfpFile_GetActualPath(inPath, outPath, inOutPathSize, outResult);
	return comptype(295).BfpFile_GetActualPath(inPath, outPath, inOutPathSize, outResult);
}

public static function comptype(1129)(comptype(79) path, comptype(626) flags, comptype(1117) outResult) sBfpFindFileData_FindFirstFile;
public static comptype(1129) BfpFindFileData_FindFirstFile(comptype(79) path, comptype(626) flags, comptype(1117) outResult)
{
	if (sBfpFindFileData_FindFirstFile != null)
		return sBfpFindFileData_FindFirstFile(path, flags, outResult);
	return comptype(295).BfpFindFileData_FindFirstFile(path, flags, outResult);
}

public static function comptype(13)(comptype(1129) findData) sBfpFindFileData_FindNextFile;
public static comptype(13) BfpFindFileData_FindNextFile(comptype(1129) findData)
{
	if (sBfpFindFileData_FindNextFile != null)
		return sBfpFindFileData_FindNextFile(findData);
	return comptype(295).BfpFindFileData_FindNextFile(findData);
}

public static function comptype(12)(comptype(1129) findData, comptype(79) outName, comptype(323) inOutNameSize, comptype(1117) outResult) sBfpFindFileData_GetFileName;
public static comptype(12) BfpFindFileData_GetFileName(comptype(1129) findData, comptype(79) outName, comptype(323) inOutNameSize, comptype(1117) outResult)
{
	if (sBfpFindFileData_GetFileName != null)
		return sBfpFindFileData_GetFileName(findData, outName, inOutNameSize, outResult);
	return comptype(295).BfpFindFileData_GetFileName(findData, outName, inOutNameSize, outResult);
}

public static function comptype(576)(comptype(1129) findData) sBfpFindFileData_GetTime_LastWrite;
public static comptype(576) BfpFindFileData_GetTime_LastWrite(comptype(1129) findData)
{
	if (sBfpFindFileData_GetTime_LastWrite != null)
		return sBfpFindFileData_GetTime_LastWrite(findData);
	return comptype(295).BfpFindFileData_GetTime_LastWrite(findData);
}

public static function comptype(576)(comptype(1129) findData) sBfpFindFileData_GetTime_Created;
public static comptype(576) BfpFindFileData_GetTime_Created(comptype(1129) findData)
{
	if (sBfpFindFileData_GetTime_Created != null)
		return sBfpFindFileData_GetTime_Created(findData);
	return comptype(295).BfpFindFileData_GetTime_Created(findData);
}

public static function comptype(576)(comptype(1129) findData) sBfpFindFileData_GetTime_Access;
public static comptype(576) BfpFindFileData_GetTime_Access(comptype(1129) findData)
{
	if (sBfpFindFileData_GetTime_Access != null)
		return sBfpFindFileData_GetTime_Access(findData);
	return comptype(295).BfpFindFileData_GetTime_Access(findData);
}

public static function comptype(565)(comptype(1129) findData) sBfpFindFileData_GetFileAttributes;
public static comptype(565) BfpFindFileData_GetFileAttributes(comptype(1129) findData)
{
	if (sBfpFindFileData_GetFileAttributes != null)
		return sBfpFindFileData_GetFileAttributes(findData);
	return comptype(295).BfpFindFileData_GetFileAttributes(findData);
}

public static function comptype(19)(comptype(1129) findData) sBfpFindFileData_GetFileSize;
public static comptype(19) BfpFindFileData_GetFileSize(comptype(1129) findData)
{
	if (sBfpFindFileData_GetFileSize != null)
		return sBfpFindFileData_GetFileSize(findData);
	return comptype(295).BfpFindFileData_GetFileSize(findData);
}

public static function comptype(12)(comptype(1129) findData) sBfpFindFileData_Release;
public static comptype(12) BfpFindFileData_Release(comptype(1129) findData)
{
	if (sBfpFindFileData_Release != null)
		return sBfpFindFileData_Release(findData);
	return comptype(295).BfpFindFileData_Release(findData);
}

